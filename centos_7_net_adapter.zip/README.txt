/etc/default/grub
grub 파일 내의 GRUB_CMDLINE_LINUX 부분의 rhgb quiet 부분의 뒤에 net.ifnames=0 biosdevname=0 를 추가한다.
grub2-mkconfig -o /boot/grub2/grub.cfg
grub 을 리빌드 하는 과정이며 반드시 아래에 done을 확인해야 한다.


인터페이스 카드 : hpe ethernet 1gb 2-port 361i adapter 전용 네트워크 드라이브 잡아준다.
cd /usr/lib/x86_64-redhat-linux6E/
rpm -ivh firmware-nic-intel-1.17.17-2.1.x86_64.rpm
cd /usr/lib/x86_64-linux-gnu/scexe-compat/CP038880.scexe